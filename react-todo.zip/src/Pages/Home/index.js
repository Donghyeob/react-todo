import React from 'react';
import InputTodo from '../../Components/InputTodo';

const Home = () => {
  return (
    <>
      <InputTodo />
    </>
  )
}

export default Home;